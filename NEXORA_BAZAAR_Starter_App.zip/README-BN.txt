NEXORA BAZAAR — Starter Prototype
বাংলা নির্দেশনা
================
public/index.html হলো মোবাইল-ফ্রেন্ডলি প্রোটোটাইপ। এতে পণ্য তালিকা, সার্চ, ক্যাটাগরি, কার্ট, চেকআউট, স্থানীয় অর্ডার লিস্ট এবং ডেমো অ্যাডমিন UI আছে।

গুরুত্বপূর্ণ:
- এটি এখনও পূর্ণাঙ্গ লাইভ দোকান নয়।
- পণ্য ও অর্ডার শুধু একই ব্রাউজারের localStorage-এ থাকে; অন্য ফোনে/অ্যাডমিনে স্বয়ংক্রিয়ভাবে দেখা যায় না।
- অ্যাডমিন প্যানেলে নিরাপদ লগইন নেই। লাইভ করার আগে authentication এবং database আবশ্যক।
- বিকাশ/নগদ এখানে শুধু পেমেন্ট পদ্ধতি নির্বাচন; স্বয়ংক্রিয় পেমেন্ট নেই।
- WhatsApp অর্ডার ইন্টিগ্রেশন এখনও যোগ করা হয়নি।
- GitHub Pages দিয়ে static prototype প্রকাশ করা যাবে, কিন্তু database/backend নয়।

পরবর্তী ধাপ: GitHub repository-তে public/index.html আপলোড করে Pages চালু; এরপর Supabase/Firebase দিয়ে secure admin, shared products/orders, image storage যুক্ত করতে হবে।
